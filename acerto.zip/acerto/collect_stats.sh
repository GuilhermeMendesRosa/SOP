#!/bin/bash

# Diretório para salvar o arquivo CSV
output_dir="/output"
output_file="${output_dir}/nginx.csv"

# Certifique-se de que o diretório existe
mkdir -p "$output_dir"

# Verificação do diretório
if [ ! -d "$output_dir" ]; then
    echo "Erro: Diretório $output_dir não existe."
    exit 1
fi

# Escrever o cabeçalho no arquivo CSV
echo "Time,CPU_Usage(%),Memory_Usage(%)" > "$output_file"

# Verificação do arquivo
if [ ! -f "$output_file" ]; then
    echo "Erro: Arquivo $output_file não pôde ser criado."
    exit 1
fi

# Função para arredondar para cima e converter para inteiro
ceil() {
    echo "$1" | awk '{print int($1) + ($1>int($1))}'
}

# Coletar dados a cada 10 segundos durante 1 minuto (6 vezes)
for i in {1..180}
do
    # Hora atual
    current_time=$(date +%H:%M:%S)
    echo "Hora atual: $current_time"  # Debug

    # Consumo de CPU em %
    cpu_usage=$(mpstat | grep 'all' | tr -s ' ' | cut -d ' ' -f 12)
    if [ -z "$cpu_usage" ]; then
        echo "Erro ao obter uso da CPU"  # Debug
        cpu_usage="N/A"
    else
        cpu_usage=$(ceil "$cpu_usage")
        cpu_usage=$((100 - cpu_usage))
    fi
    echo "Consumo de CPU: $cpu_usage"  # Debug

    # Consumo de Memória em %
    memory_usage=$(free | grep Mem | awk '{print $3/$2 * 100.0}')
    if [ -z "$memory_usage" ]; then
        echo "Erro ao obter uso da memória"  # Debug
        memory_usage="N/A"
    else
        memory_usage=$(ceil "$memory_usage")
    fi
    echo "Consumo de Memória: $memory_usage"  # Debug

    # Escrever os dados no arquivo CSV
    echo "$current_time,$cpu_usage,$memory_usage" >> "$output_file"
    echo "Dados escritos: $current_time,$cpu_usage,$memory_usage"  # Debug

    # Aguardar 10 segundos antes de coletar os próximos dados
    sleep 10
done

echo "Dados salvos em $output_file"
