#!/bin/sh
nginx -c $HOME/nginx.conf
sleep 5
